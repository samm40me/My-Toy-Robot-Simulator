#rom run import main
#import fileinput
import argparse
import compass
import command
from compass import Robot
from command import parse, InvalidCommand


def first_input():
    """Run Mr Robot, run!

    Simulate a robot interactively."""
    robot = Robot()
    with open('sample_a.txt', 'r') as fp1:
        count = 0    
        for line in fp1:
            try:

                (cmd, coords) = parse(line)
                if cmd == 'PLACE':
                    robot.place(coords)
                    count += 1
                else:
                # Assume Robot has a method for each valid command.
                # (A potential weak point, but this is covered sufficiently by
                # the command_pattern testing)
                    getattr(robot, cmd.lower())()

            except InvalidCommand:
            # Silently ignore invalid commands
                pass

def second_input():
    """Run Mr Robot, run!

    Simulate a robot interactively."""
    robot = Robot()
    with open('sample_b.txt', 'r') as fp2:
 #   lines = fp.readlines
     count = 0    
     for line in fp2:
        try:

            (cmd, coords) = parse(line)
            if cmd == 'PLACE':
                robot.place(coords)
                count += 1
            else:
                # Assume Robot has a method for each valid command.
                # (A potential weak point, but this is covered sufficiently by
                # the command_pattern testing)
                getattr(robot, cmd.lower())()

        except InvalidCommand:
            # Silently ignore invalid commands
            pass
def third_input():
    """Run Mr Robot, run!

    Simulate a robot interactively."""
    robot = Robot()
    with open('sample_c.txt', 'r') as fp3:
 #   lines = fp.readlines
     count = 0    
     for line in fp3:
        try:

            (cmd, coords) = parse(line)
            if cmd == 'PLACE':
                robot.place(coords)
                count += 1
            else:
                # Assume Robot has a method for each valid command.
                # (A potential weak point, but this is covered sufficiently by
                # the command_pattern testing)
                getattr(robot, cmd.lower())()
        except InvalidCommand:
            # Silently ignore invalid commands
            pass  
print("User Inputs are: \n")
fa = open("sample_a.txt", "r")
print(fa.read())
f2 = open("sample_b.txt", "r")
print(f2.read())
fc = open("sample_c.txt", "r")
print(fc.read())
print("User outputs are: \n")
first_input()
second_input()
third_input()